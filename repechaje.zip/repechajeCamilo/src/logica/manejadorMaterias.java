package logica;

import persistencia.manejadorDB;

public class manejadorMaterias {

	
	public void create(Materia materia) {
		manejadorDB.createMateria(materia.getCodigo(),materia.getNombre());
	}
	
	public void edit(Materia materia) {
		manejadorDB.editMateria(materia.getCodigo(),materia.getNombre());
	}
	
	public void delete(Materia materia) {
		manejadorDB.deleteMateria(materia.getCodigo(),materia.getNombre());
	}
	
	public Materia get(int codigo) {
		return manejadorDB.getMateria(codigo);
	}
}
