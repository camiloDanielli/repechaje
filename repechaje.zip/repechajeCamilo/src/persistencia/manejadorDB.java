package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import logica.Materia;
import logica.Usuario;

public class manejadorDB {

	public static void createUsuario(int ci, String nombre, String apellido) {
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {

			Statement stmt = con.createStatement();

			String query = "INSERT INTO Usuarios (ci,nombre,apellido) " 
			+ "VALUES (" + ci + ",'" + nombre + "','"
					+ apellido + "')";
			stmt.executeQuery(query);
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public static void deleteUsuario(int ci) {
		// TODO Auto-generated method stub
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {

			Statement stmt = con.createStatement();

			String query2 = "DELETE Usuarios " + "where " + ci + "= ci";
			stmt.executeQuery(query2);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void updateUsuario(int ci, String nombre, String apellido) {

		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {
			Statement stmt = con.createStatement();

			String query3 = "UPDATE usuarios" + "SET ci=" + ci + ", nombre='" + nombre + "', apellido='" + apellido
					+ "'" + "WHERE ci=" + ci +";";
			stmt.executeQuery(query3);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static  Usuario getUsuario(int ci) {
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {
			Statement stmt = con.createStatement();

			String get = "SELECT * FROM usuarios WHERE ci=" + ci +";";
			PreparedStatement ps = con.prepareStatement(get);
			ResultSet rs = ps.executeQuery();
			Usuario res = null;
			res.setCi(rs.getInt("ci"));
			res.setNombre(rs.getString("nombre"));
			res.setApellido(rs.getString("apellido"));
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	

	public static void createMateria(int codigo, String nombre) {
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {

			Statement stmt = con.createStatement();

			String query = "INSERT INTO Materias (codigo,nombre) " 
			+ "VALUES (" + codigo + ",'" + nombre + "');";
			stmt.executeQuery(query);
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public static void editMateria(int codigo, String nombre) {
		// TODO Auto-generated method stub
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {
			Statement stmt = con.createStatement();

			String query3 = "INSERT INTO Materias(codigo, nombre) " + "VALUES (codigo='" + codigo + "',nombre='"
					+ nombre + "')";
			stmt.executeQuery(query3);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static Materia getMateria(int codigo) {
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {
			Statement stmt = con.createStatement();

			String get = "SELECT * FROM Materias WHERE codgo=" + codigo +";";
			PreparedStatement ps = con.prepareStatement(get);
			ResultSet rs = ps.executeQuery();
			Materia res = null;
			res.setCodigo(rs.getInt("codigo"));
			res.setNombre(rs.getString("nombre"));
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}

	public static void deleteMateria(int codigo, String nombre) {
		// TODO Auto-generated method stub
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		try {
			Statement stmt = con.createStatement();

			String query3 = "INSERT INTO Materias(codigo, nombre) " + "VALUES (codigo='" + codigo + "',nombre='"
					+ nombre + "')";
			stmt.executeQuery(query3);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	


}
