package logica;

public class manejadorMaterias {

	
	public newMateria(int codigo, String nombre){
		
	}
}
