package logica;

public class manejadorUsuarios {

}
