package persistencia;

public class manejadorDB {

}
